package ru.wcma.helper;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.view.accessibility.AccessibilityManager;
import java.util.List;

public class MainActivity extends android.app.Activity {
    private TextView status;
    private EditText packageField;
    @Override public void onCreate(Bundle b) { super.onCreate(b); build(); }
    @Override protected void onResume() { super.onResume(); if (status != null) updateStatus(); }
    private void build() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(40,40,40,40);
        TextView title = new TextView(this); title.setText("WCMA Helper"); title.setTextSize(28); title.setGravity(Gravity.CENTER); root.addView(title, lp());
        TextView info = new TextView(this); info.setText("MS300R Bluetooth HID → Helper → focused WCMA field\n\nThe helper collects scanner keystrokes until Enter, then inserts the complete scan into the focused editable control."); info.setTextSize(17); root.addView(info, lp());
        status = new TextView(this); status.setTextSize(17); status.setPadding(0,30,0,30); root.addView(status, lp());
        packageField = new EditText(this); packageField.setHint("Optional WCMA package name"); packageField.setInputType(InputType.TYPE_CLASS_TEXT); root.addView(packageField, lp());
        Button save = new Button(this); save.setText("Save package name"); save.setOnClickListener(v -> { getPreferences(0).edit().putString("wcma_package", packageField.getText().toString().trim()).apply(); Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show(); }); root.addView(save, lp());
        Button open = new Button(this); open.setText("Open Accessibility settings"); open.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); root.addView(open, lp());
        TextView test = new TextView(this); test.setText("Test: enable the service, pair MS300R as a Bluetooth keyboard, open WCMA, focus the scan/input field, then scan a QR/barcode."); test.setTextSize(15); test.setPadding(0,30,0,0); root.addView(test, lp());
        setContentView(root); packageField.setText(getPreferences(0).getString("wcma_package","")); updateStatus();
    }
    private LinearLayout.LayoutParams lp() { return new LinearLayout.LayoutParams(-1,-2); }
    private void updateStatus() {
        AccessibilityManager am=(AccessibilityManager)getSystemService(ACCESSIBILITY_SERVICE); boolean on=false;
        if(am!=null){ List<AccessibilityServiceInfo> list=am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK); String me=getPackageName(); for(AccessibilityServiceInfo i:list){ if(i.getResolveInfo()!=null && me.equals(i.getResolveInfo().serviceInfo.packageName)){on=true;break;} } }
        status.setText("Accessibility service: " + (on ? "ON" : "OFF"));
    }
}
