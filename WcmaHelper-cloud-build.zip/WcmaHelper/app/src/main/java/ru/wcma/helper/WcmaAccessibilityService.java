package ru.wcma.helper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Locale;

public class WcmaAccessibilityService extends AccessibilityService {
    private final StringBuilder buffer = new StringBuilder();
    private long lastKeyTime = 0;
    private static final long GAP_MS = 1200;

    @Override protected void onServiceConnected() {
        AccessibilityServiceInfo i = getServiceInfo();
        if (i == null) i = new AccessibilityServiceInfo();
        i.flags |= AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        i.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED | AccessibilityEvent.TYPE_VIEW_FOCUSED;
        i.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        setServiceInfo(i);
    }
    @Override public boolean onKeyEvent(KeyEvent e) {
        if (e.getAction() != KeyEvent.ACTION_DOWN) return false;
        long now=System.currentTimeMillis(); if(lastKeyTime>0 && now-lastKeyTime>GAP_MS) buffer.setLength(0); lastKeyTime=now;
        int code=e.getKeyCode();
        if(code==KeyEvent.KEYCODE_ENTER || code==KeyEvent.KEYCODE_NUMPAD_ENTER){ if(buffer.length()>0){ String s=buffer.toString(); buffer.setLength(0); deliver(s); } return true; }
        if(code==KeyEvent.KEYCODE_DEL || code==KeyEvent.KEYCODE_ESCAPE){ buffer.setLength(0); return true; }
        int uc=e.getUnicodeChar(e.getMetaState()); if(uc!=0 && !Character.isISOControl(uc)){ buffer.appendCodePoint(uc); return true; }
        return false;
    }
    private void deliver(String text){
        AccessibilityNodeInfo root=getRootInActiveWindow(); AccessibilityNodeInfo target=findFocusedEditable(root); if(target==null && root!=null) target=findEditable(root);
        boolean ok=false;
        if(target!=null){ Bundle args=new Bundle(); args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,text); ok=target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args); }
        if(!ok){ ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE); if(cm!=null) cm.setPrimaryClip(ClipData.newPlainText("WCMA scan",text)); }
    }
    private AccessibilityNodeInfo findFocusedEditable(AccessibilityNodeInfo n){ if(n==null)return null; if(n.isFocused() && n.isEditable())return n; for(int x=0;x<n.getChildCount();x++){ AccessibilityNodeInfo r=findFocusedEditable(n.getChild(x)); if(r!=null)return r; } return null; }
    private AccessibilityNodeInfo findEditable(AccessibilityNodeInfo n){ if(n==null)return null; if(n.isEditable())return n; for(int x=0;x<n.getChildCount();x++){ AccessibilityNodeInfo r=findEditable(n.getChild(x)); if(r!=null)return r; } return null; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { buffer.setLength(0); }
}
