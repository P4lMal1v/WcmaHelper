# WcmaHelper

Android helper for testing a Bluetooth HID MS300R scanner with WCMA.

Flow:

`MS300R (Bluetooth HID) -> WcmaHelper Accessibility Service -> WCMA`

The helper collects HID characters until Enter and tries to put the complete scan into the currently focused editable WCMA field. If no editable node can be used, it copies the scan to the clipboard as a fallback.

## Build the APK without a PC

This project includes `.github/workflows/build-apk.yml`.

1. Create a GitHub repository from a phone/browser.
2. Upload the complete contents of this project to the repository.
3. Open the repository's **Actions** tab.
4. Select **Build WcmaHelper APK**.
5. Tap **Run workflow** (or push to `main`, which starts the workflow automatically).
6. When the run finishes, open the run and download the artifact named **WcmaHelper-debug-apk**.
7. Extract it and install `app-debug.apk` on Android.

No Android Studio or local PC is required; GitHub's hosted runner supplies Java, Gradle, and the Android SDK.

## Install/test

1. Install the APK.
2. Open WcmaHelper.
3. Enable its Accessibility Service in Android Accessibility settings.
4. Pair MS300R as a Bluetooth HID keyboard.
5. Open WCMA and place focus where the scan should be entered.
6. Scan a QR code such as `https://wsh.bike?s=PD7629`.
7. The helper should collect the HID characters and Enter, then inject the complete string.

This is the first generic HID-to-editable-field implementation. If WCMA does not expose an editable node at the required point, the next step is a WCMA-specific integration after observing the live test result.
